package com.example.litelauncher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator

/** Screen ke border pe ghumti hui rangeen light (edge lighting). */
class EdgeLightView(ctx: Context) : View(ctx) {

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val m = Matrix()
    private var shader: SweepGradient? = null
    private var colors = intArrayOf(Color.CYAN, Color.MAGENTA, Color.CYAN)
    private var angle = 0f
    private var pulseAlpha = 1f
    private var spin: ValueAnimator? = null
    private var pulse: ValueAnimator? = null
    private val radius = 34f * density
    private val widths = floatArrayOf(16f, 9f, 4f)
    private val alphas = intArrayOf(40, 90, 255)

    fun setMode(cols: IntArray, spinMs: Long, pulsing: Boolean) {
        colors = cols + cols[0]
        rebuild()
        spin?.cancel()
        spin = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = spinMs
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
        pulse?.cancel()
        pulseAlpha = 1f
        if (pulsing) {
            pulse = ValueAnimator.ofFloat(0.45f, 1f).apply {
                duration = 700
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener { pulseAlpha = it.animatedValue as Float }
                start()
            }
        }
    }

    fun stop() {
        spin?.cancel()
        pulse?.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        if (width == 0 || height == 0) return
        shader = SweepGradient(width / 2f, height / 2f, colors, null)
    }

    override fun onDraw(c: Canvas) {
        val s = shader ?: return
        m.setRotate(angle, width / 2f, height / 2f)
        s.setLocalMatrix(m)
        paint.shader = s
        for (k in 0..2) {
            val w = widths[k] * density
            paint.strokeWidth = w
            paint.alpha = (alphas[k] * pulseAlpha).toInt()
            val i = w / 2
            c.drawRoundRect(i, i, width - i, height - i, radius, radius, paint)
        }
    }
}

package com.example.litelauncher

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.graphics.PixelFormat
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.media.MediaMetadata
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.NotificationListenerService.Ranking
import android.service.notification.StatusBarNotification
import android.view.WindowManager

/**
 * Notification / call / music aane par screen ke border pe light chalati hai.
 * Notification access + "Display over other apps" permission chahiye.
 */
class EdgeLightService : NotificationListenerService() {

    companion object {
        @Volatile var instance: EdgeLightService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("lite", MODE_PRIVATE) }
    private var view: EdgeLightView? = null
    private var curMode = -1
    private var callUntil = 0L
    private var notifUntil = 0L
    private var musicUntil = 0L
    private var wasPlaying = false
    private val controllers = mutableListOf<MediaController>()
    private val evalRunnable = Runnable { evaluate() }

    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { checkMusic(false) }
        override fun onMetadataChanged(metadata: MediaMetadata?) { checkMusic(true) }
    }

    private val sessListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        setControllers(list ?: emptyList())
    }

    // ---------- Service lifecycle ----------
    override fun onListenerConnected() {
        instance = this
        try {
            val msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val cn = ComponentName(this, EdgeLightService::class.java)
            msm.addOnActiveSessionsChangedListener(sessListener, cn)
            setControllers(msm.getActiveSessions(cn))
        } catch (e: Exception) { }
    }

    override fun onListenerDisconnected() {
        instance = null
        hide()
    }

    override fun onDestroy() {
        instance = null
        try {
            (getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager)
                .removeOnActiveSessionsChangedListener(sessListener)
        } catch (e: Exception) { }
        super.onDestroy()
    }

    // ---------- Notifications / calls ----------
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        val now = SystemClock.uptimeMillis()

        if (n.category == Notification.CATEGORY_CALL) {
            callUntil = now + 30000 // ringing ke liye max 30 sec, call katne pe turant band
            evaluate()
            return
        }
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_PROGRESS) return
        if (sbn.isOngoing) return

        val r = Ranking()
        if (currentRanking.getRanking(sbn.key, r) && r.importance < NotificationManager.IMPORTANCE_DEFAULT) return

        notifUntil = now + 3500
        evaluate()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.notification.category == Notification.CATEGORY_CALL) {
            callUntil = 0
            evaluate()
        }
    }

    // ---------- Music ----------
    private fun setControllers(list: List<MediaController>) {
        controllers.forEach { it.unregisterCallback(mediaCb) }
        controllers.clear()
        controllers.addAll(list)
        controllers.forEach { it.registerCallback(mediaCb) }
        wasPlaying = controllers.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
    }

    private fun checkMusic(burst: Boolean) {
        val playing = controllers.any { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        if (playing && (burst || !wasPlaying)) {
            musicUntil = SystemClock.uptimeMillis() + 5000
            evaluate()
        }
        wasPlaying = playing
    }

    fun test() {
        notifUntil = SystemClock.uptimeMillis() + 3500
        evaluate()
    }

    // ---------- Overlay ----------
    private fun evaluate() {
        h.removeCallbacks(evalRunnable)
        val now = SystemClock.uptimeMillis()
        val mode = when {
            callUntil > now -> 0
            notifUntil > now -> 1
            musicUntil > now -> 2
            else -> -1
        }
        if (mode < 0) hide() else show(mode)
        val next = listOf(callUntil, notifUntil, musicUntil).filter { it > now }.minOrNull()
        if (next != null) h.postDelayed(evalRunnable, next - now + 50)
    }

    private fun palette(mode: Int): IntArray = when (mode) {
        0 -> intArrayOf(0xFF00E676.toInt(), 0xFF00B0FF.toInt(), 0xFF69F0AE.toInt())
        2 -> intArrayOf(0xFFFF4081.toInt(), 0xFFB388FF.toInt(), 0xFFFF80AB.toInt())
        else -> when (prefs.getInt("edgePalette", 0)) {
            1 -> intArrayOf(0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFF18FFFF.toInt())
            2 -> intArrayOf(0xFFFF9100.toInt(), 0xFFFF4081.toInt(), 0xFFFFD740.toInt())
            else -> intArrayOf(
                0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt(),
                0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFD500F9.toInt()
            )
        }
    }

    private fun show(mode: Int) {
        if (!prefs.getBoolean("edge", true) || !Settings.canDrawOverlays(this)) { hide(); return }
        var v = view
        if (v == null) {
            v = EdgeLightView(this)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            } catch (e: Exception) { return }
            view = v
            curMode = -1
        }
        v.animate().cancel()
        v.alpha = 1f
        if (mode != curMode) {
            curMode = mode
            v.setMode(palette(mode), if (mode == 0) 1400L else if (mode == 2) 3500L else 2200L, mode == 0)
        }
    }

    private fun hide() {
        val v = view ?: return
        view = null
        curMode = -1
        v.animate().alpha(0f).setDuration(300).withEndAction {
            v.stop()
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) { }
        }.start()
    }
}

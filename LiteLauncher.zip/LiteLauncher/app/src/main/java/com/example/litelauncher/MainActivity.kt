package com.example.litelauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.WallpaperColors
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val pkg: String, val icon: Drawable, val launch: Intent)
data class Style(val shape: Int, val iconPx: Int, val labelColor: Int, val anim: Int)

fun applyShape(v: View, mode: Int) {
    if (mode == 3) { v.clipToOutline = false; return }
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            val r = when (mode) { 0 -> view.width / 2f; 1 -> view.width * 0.3f; else -> view.width * 0.1f }
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }
    v.clipToOutline = true
}

/** Touch pe spring jaisa press effect. mode: 0 off, 1 lite, 2 full */
fun pressAnim(v: View, mode: Int) {
    if (mode == 0) { v.setOnTouchListener(null); return }
    v.setOnTouchListener { view, ev ->
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                view.animate().setStartDelay(0).scaleX(0.9f).scaleY(0.9f).setDuration(90)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                view.animate().setStartDelay(0).scaleX(1f).scaleY(1f)
                    .setDuration(if (mode == 2) 340L else 120L)
                    .setInterpolator(if (mode == 2) OvershootInterpolator(3f) else DecelerateInterpolator())
                    .start()
        }
        false
    }
}

class MainActivity : Activity() {

    private lateinit var drawer: View
    private lateinit var grid: RecyclerView
    private lateinit var search: EditText
    private lateinit var dock: LinearLayout
    private lateinit var clock: TextClock
    private lateinit var date: TextClock
    private lateinit var detector: GestureDetector
    private var all: List<AppItem> = emptyList()
    private val prefs by lazy { getSharedPreferences("lite", MODE_PRIVATE) }

    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val batReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { if (i != null) updateBattery(i) }
    }

    private var accent = Color.BLACK
    private var darkText = false

    private val themeNames = arrayOf("Auto (system)", "Light", "Dark")
    private val shapeNames = arrayOf("Circle", "Squircle", "Rounded square", "Original")
    private val sizeNames = arrayOf("Small", "Medium", "Large")
    private val sizeDp = intArrayOf(40, 48, 56)

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { loadApps() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cols() = prefs.getInt("cols", 4)

    private fun isDark(): Boolean = when (prefs.getInt("theme", 0)) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun style() = Style(
        prefs.getInt("shape", 0),
        dp(sizeDp[prefs.getInt("size", 1)]),
        if (isDark()) Color.WHITE else 0xFF222222.toInt(),
        prefs.getInt("anim", 2)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawer = findViewById(R.id.drawer)
        grid = findViewById(R.id.grid)
        search = findViewById(R.id.search)
        dock = findViewById(R.id.dock)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        setupStatusBar()
        grid.layoutManager = GridLayoutManager(this, cols())
        grid.setHasFixedSize(true)

        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (vy < -1000 && drawer.visibility != View.VISIBLE) { openDrawer(); return true }
                return false
            }
        })

        findViewById<View>(R.id.btnAll).setOnClickListener { openDrawer() }
        findViewById<View>(R.id.btnClean).setOnClickListener { cleanBackground() }
        findViewById<View>(R.id.btnStyle).setOnClickListener { styleMenu() }
        findViewById<View>(R.id.btnGame).setOnClickListener { gameMenu() }
        findViewById<View>(R.id.btnEdge).setOnClickListener { edgeMenu() }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                val q = s.toString().trim().lowercase()
                showList(if (q.isEmpty()) all else all.filter { it.label.lowercase().contains(q) })
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        applyStyle()
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        applyStyle() // wallpaper badla ho to colors dobara
        restoreDnd()
        playIntro()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(pkgReceiver)
        try { unregisterReceiver(batReceiver) } catch (e: Exception) { }
        try { netCb?.let { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } } catch (e: Exception) { }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (drawer.visibility == View.VISIBLE) closeDrawer()
    }

    // ---------- Dynamic colors + light/dark ----------
    private fun readWallpaper() {
        accent = Color.BLACK
        darkText = false
        if (Build.VERSION.SDK_INT >= 27 && prefs.getBoolean("dyn", true)) {
            try {
                val c = WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (c != null) {
                    accent = c.primaryColor.toArgb()
                    darkText = (c.colorHints and WallpaperColors.HINT_SUPPORTS_DARK_TEXT) != 0
                }
            } catch (e: Exception) { }
        }
    }

    private fun withAlpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun blend(a: Int, b: Int, r: Float): Int {
        val ir = 1 - r
        return Color.argb(
            Color.alpha(a),
            (Color.red(a) * ir + Color.red(b) * r).toInt(),
            (Color.green(a) * ir + Color.green(b) * r).toInt(),
            (Color.blue(a) * ir + Color.blue(b) * r).toInt()
        )
    }

    // Liquid glass: gradient border (ring) + upar se halka chamakta body
    private fun glass(fill: Int, radiusDp: Int): Drawable {
        val r = dp(radiusDp).toFloat()
        val ring = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xAAFFFFFF.toInt(), 0x14FFFFFF, 0x66FFFFFF)
        ).apply { cornerRadius = r }
        val body = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(blend(fill, Color.WHITE, 0.30f), fill)
        ).apply { cornerRadius = (r - dp(1)).coerceAtLeast(0f) }
        return LayerDrawable(arrayOf(ring, body)).apply { setLayerInset(1, dp(1), dp(1), dp(1), dp(1)) }
    }

    private fun applyStyle() {
        readWallpaper()
        val dark = isDark()
        val tc = if (darkText) 0xFF111111.toInt() else Color.WHITE
        clock.setTextColor(tc)
        date.setTextColor(tc)
        intArrayOf(R.id.stNet, R.id.stBat, R.id.btnStyle, R.id.btnClean, R.id.btnAll, R.id.btnGame, R.id.btnEdge).forEach {
            val t = findViewById<TextView>(it)
            t.setTextColor(tc)
            t.background = glass(withAlpha(accent, 0x55), 40)
            pressAnim(t, prefs.getInt("anim", 2))
        }
        dock.background = glass(withAlpha(accent, 0x66), 32)

        val base = if (dark) 0xF2101418.toInt() else 0xF2F4F5F7.toInt()
        val tint = blend(base, accent, 0.12f)
        drawer.setBackgroundColor(if (blurAvailable()) withAlpha(tint, 0x99) else tint)
        search.setTextColor(if (dark) Color.WHITE else 0xFF222222.toInt())
        search.setHintTextColor(if (dark) 0x99FFFFFF.toInt() else 0x99000000.toInt())
        search.background = glass(if (dark) 0x33FFFFFF else 0x14000000, 40)

        // Transparent status bar, wallpaper ke upar
        window.statusBarColor = Color.TRANSPARENT
        var flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        if (darkText && Build.VERSION.SDK_INT >= 23) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        window.decorView.systemUiVisibility = flags
    }

    private fun refresh() {
        applyStyle()
        grid.layoutManager = GridLayoutManager(this, cols())
        showList(all)
        buildDock()
    }

    // ---------- Style menu ----------
    private val animNames = arrayOf("Off", "Lite", "Full")

    private fun styleMenu() {
        val items = arrayOf(
            "Theme: ${themeNames[prefs.getInt("theme", 0)]}",
            "Icon shape: ${shapeNames[prefs.getInt("shape", 0)]}",
            "Icon size: ${sizeNames[prefs.getInt("size", 1)]}",
            "Grid: ${cols()} columns",
            "Dynamic colors: ${if (prefs.getBoolean("dyn", true)) "ON" else "OFF"}",
            "Animations: ${animNames[prefs.getInt("anim", 2)]}",
            "Change wallpaper"
        )
        AlertDialog.Builder(this).setTitle("Style").setItems(items) { _, i ->
            when (i) {
                0 -> choose("Theme", themeNames, "theme")
                1 -> choose("Icon shape", shapeNames, "shape")
                2 -> choose("Icon size", sizeNames, "size")
                3 -> { prefs.edit().putInt("cols", if (cols() == 4) 5 else 4).apply(); refresh() }
                4 -> { prefs.edit().putBoolean("dyn", !prefs.getBoolean("dyn", true)).apply(); refresh() }
                5 -> choose("Animations (phone slow ho to Lite/Off)", animNames, "anim")
                6 -> try {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Wallpaper picker nahi mila", Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }.show()
    }

    private fun choose(title: String, names: Array<String>, key: String) {
        AlertDialog.Builder(this).setTitle(title).setItems(names) { _, i ->
            prefs.edit().putInt(key, i).apply()
            if (key == "theme") recreate() else refresh()
        }.show()
    }

    // ---------- Apps ----------
    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val i = Intent(Intent.ACTION_MAIN)
                        .setComponent(ComponentName(it.activityInfo.packageName, it.activityInfo.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm), i)
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { all = list; showList(list); buildDock() }
        }.start()
    }

    private fun showList(list: List<AppItem>, intro: Boolean = false) {
        grid.adapter = AppAdapter(list, style(), intro, { launch(it) }, { options(it) })
    }

    private fun launch(app: AppItem) {
        try { startActivity(app.launch) } catch (e: Exception) {
            Toast.makeText(this, "App khul nahi rahi", Toast.LENGTH_SHORT).show()
        }
        closeDrawer()
    }

    private fun blurAvailable(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return false
        return try { (getSystemService(WINDOW_SERVICE) as WindowManager).isCrossWindowBlurEnabled } catch (e: Throwable) { false }
    }

    private fun setBlur(on: Boolean) {
        if (!blurAvailable()) return
        try { window.setBackgroundBlurRadius(if (on) dp(40) else 0) } catch (e: Throwable) { }
    }

    private fun openDrawer() {
        val a = prefs.getInt("anim", 2)
        drawer.animate().cancel()
        search.setText("")
        showList(all, a == 2)
        setBlur(true)
        drawer.visibility = View.VISIBLE
        if (a == 0) { drawer.alpha = 1f; drawer.translationY = 0f; return }
        drawer.alpha = 0f
        drawer.translationY = dp(80).toFloat()
        drawer.animate().alpha(1f).translationY(0f)
            .setDuration(if (a == 2) 380L else 200L)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun closeDrawer() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        if (drawer.visibility != View.VISIBLE) return
        setBlur(false)
        val a = prefs.getInt("anim", 2)
        drawer.animate().cancel()
        if (a == 0) {
            drawer.visibility = View.GONE
            search.setText("")
            return
        }
        drawer.animate().alpha(0f).translationY(dp(60).toFloat())
            .setDuration(if (a == 2) 260L else 160L)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                drawer.visibility = View.GONE
                drawer.alpha = 1f
                drawer.translationY = 0f
                search.setText("")
            }.start()
    }

    // Home pe wapas aane par clock/date/dock slide-in
    private fun playIntro() {
        if (prefs.getInt("anim", 2) != 2) return
        val targets = listOf<Pair<View, Int>>(clock to 30, date to 36, dock to 80)
        targets.forEachIndexed { i, (v, dy) ->
            v.alpha = 0f
            v.translationY = dy.toFloat()
            v.animate().setStartDelay(i * 60L).alpha(1f).translationY(0f)
                .setDuration(380).setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
    }

    // ---------- Dock ----------
    private fun dockPkgs(): List<String> {
        val saved = prefs.getString("dock", null)
        if (saved != null) return saved.split(",").filter { it.isNotEmpty() }
        return listOf("phone", "messages", "camera", "chrome")
            .mapNotNull { n -> all.firstOrNull { it.label.equals(n, true) }?.pkg }
    }

    private fun buildDock() {
        dock.removeAllViews()
        val shape = prefs.getInt("shape", 0)
        dockPkgs().mapNotNull { p -> all.firstOrNull { it.pkg == p } }.forEachIndexed { idx, app ->
            val v = ImageView(this)
            v.layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(dp(5), 0, dp(5), 0) }
            v.setImageDrawable(app.icon)
            applyShape(v, shape)
            v.setOnClickListener { launch(app) }
            v.setOnLongClickListener { options(app); true }
            dock.addView(v)
            val an = prefs.getInt("anim", 2)
            pressAnim(v, an)
            if (an == 2) {
                v.scaleX = 0f; v.scaleY = 0f
                v.animate().setStartDelay(idx * 70L + 120).scaleX(1f).scaleY(1f)
                    .setDuration(420).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
        }
    }

    private fun options(app: AppItem) {
        val inDock = dockPkgs().contains(app.pkg)
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(arrayOf(if (inDock) "Dock se hatao" else "Dock mein lagao", "App info")) { _, i ->
                if (i == 0) {
                    val l = dockPkgs().toMutableList()
                    if (inDock) l.remove(app.pkg) else { if (l.size >= 5) l.removeAt(0); l.add(app.pkg) }
                    prefs.edit().putString("dock", l.joinToString(",")).apply()
                    buildDock()
                } else {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }.show()
    }

    // ---------- Status pills (Wi-Fi / data / battery) ----------
    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun setupStatusBar() {
        val sb = statusBarHeight()
        findViewById<View>(R.id.home).setPadding(dp(24), sb + dp(12), dp(24), dp(24))
        drawer.setPadding(dp(12), sb + dp(16), dp(12), 0)

        findViewById<View>(R.id.stNet).setOnClickListener {
            try { startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
            catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (e2: Exception) { } }
        }
        findViewById<View>(R.id.stBat).setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) } catch (e: Exception) { }
        }

        registerReceiver(batReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { updateBattery(it) }

        if (Build.VERSION.SDK_INT >= 24) {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { showNet(caps) }
                override fun onLost(network: Network) { showNet(null) }
            }
            netCb = cb
            try { cm.registerDefaultNetworkCallback(cb) } catch (e: Exception) { }
        }
    }

    private fun updateBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else 0
        val extra = if (charging) " ⚡" else ""
        findViewById<TextView>(R.id.stBat).text = "$pct%$extra"
    }

    private fun showNet(caps: NetworkCapabilities?) {
        val t = when {
            caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "No internet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi " + wifiBars(caps)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            else -> "Connected"
        }
        runOnUiThread { findViewById<TextView>(R.id.stNet).text = t }
    }

    private fun wifiBars(caps: NetworkCapabilities): String {
        if (Build.VERSION.SDK_INT < 29) return ""
        val rssi = caps.signalStrength
        if (rssi == Int.MIN_VALUE) return ""
        val bars = when { rssi > -55 -> 4; rssi > -65 -> 3; rssi > -75 -> 2; else -> 1 }
        return "▂▄▆█".take(bars)
    }

    // ---------- Edge light ----------
    private val paletteNames = arrayOf("Rainbow", "Aqua", "Sunset")

    private fun hasNotifAccess() =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)

    private fun hasOverlay() = Settings.canDrawOverlays(this)

    private fun edgeMenu() {
        val on = prefs.getBoolean("edge", true)
        val items = arrayOf(
            "Edge light: ${if (on) "ON" else "OFF"}",
            "Colors: ${paletteNames[prefs.getInt("edgePalette", 0)]}",
            "Test karo",
            "Notification access: ${if (hasNotifAccess()) "OK" else "dena hai"}",
            "Display over apps: ${if (hasOverlay()) "OK" else "dena hai"}"
        )
        AlertDialog.Builder(this).setTitle("Edge Light").setItems(items) { _, i ->
            when (i) {
                0 -> prefs.edit().putBoolean("edge", !on).apply()
                1 -> choose("Edge colors", paletteNames, "edgePalette")
                2 -> {
                    val svc = EdgeLightService.instance
                    if (svc != null && hasOverlay()) svc.test()
                    else Toast.makeText(this, "Pehle dono permission do", Toast.LENGTH_LONG).show()
                }
                3 -> try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
                4 -> try {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) { }
                else -> {}
            }
        }.show()
    }

    // ---------- Game mode ----------
    private fun gameMenu() {
        val games = prefs.getStringSet("games", emptySet()) ?: emptySet()
        val list = all.filter { games.contains(it.pkg) }
        val names = list.map { it.label } + listOf("+ Games chuno", "DND access (notifications block)")
        AlertDialog.Builder(this).setTitle("Game Mode").setItems(names.toTypedArray()) { _, i ->
            when {
                i < list.size -> boostAndPlay(list[i])
                i == list.size -> pickGames()
                else -> try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { }
            }
        }.show()
    }

    private fun pickGames() {
        val cur = prefs.getStringSet("games", emptySet()) ?: emptySet()
        val checked = BooleanArray(all.size) { cur.contains(all[it].pkg) }
        AlertDialog.Builder(this)
            .setTitle("Games chuno")
            .setMultiChoiceItems(all.map { it.label }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                val set = all.filterIndexed { i, _ -> checked[i] }.map { it.pkg }.toSet()
                prefs.edit().putStringSet("games", set).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun boostAndPlay(app: AppItem) {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        all.filter { it.pkg != app.pkg }.forEach { am.killBackgroundProcesses(it.pkg) }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        var dnd = false
        if (nm.isNotificationPolicyAccessGranted) {
            prefs.edit()
                .putInt("prevFilter", nm.currentInterruptionFilter)
                .putBoolean("gameDnd", true).apply()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            dnd = true
        }
        Toast.makeText(this, if (dnd) "Game Mode: RAM saaf + DND ON" else "Game Mode: RAM saaf", Toast.LENGTH_SHORT).show()
        launch(app)
    }

    // Game se wapas Home aane par DND pehle jaisa
    private fun restoreDnd() {
        if (!prefs.getBoolean("gameDnd", false)) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(prefs.getInt("prevFilter", NotificationManager.INTERRUPTION_FILTER_ALL))
        }
        prefs.edit().putBoolean("gameDnd", false).apply()
    }

    // ---------- Background apps ----------
    private fun cleanBackground() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        all.forEach { am.killBackgroundProcesses(it.pkg) }
        Toast.makeText(this, "Background apps saaf kar di gayi", Toast.LENGTH_SHORT).show()
    }
}

class AppAdapter(
    private val items: List<AppItem>,
    private val style: Style,
    private val intro: Boolean,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        h.icon.layoutParams = h.icon.layoutParams.apply { width = style.iconPx; height = style.iconPx }
        applyShape(h.icon, style.shape)
        h.icon.setImageDrawable(item.icon)
        h.label.text = item.label
        h.label.setTextColor(style.labelColor)
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnLongClickListener { onLong(item); true }

        h.itemView.animate().cancel()
        h.itemView.alpha = 1f
        h.itemView.translationY = 0f
        pressAnim(h.itemView, style.anim)
        if (intro && style.anim == 2 && position < 20) {
            h.itemView.alpha = 0f
            h.itemView.translationY = 48f
            h.itemView.animate().setStartDelay(position * 20L).alpha(1f).translationY(0f)
                .setDuration(300).setInterpolator(DecelerateInterpolator(1.5f)).start()
        }
    }

    override fun getItemCount() = items.size
}
